---
name: new-video
description: >
  This skill should be used when the user runs /new-video or asks to "start a new 2D video", "set up a video
  from this voiceover", "timestamp my voiceover", "transcribe and time my narration", "import my SRT/timestamped
  script", or "plan the shots for my script" in the GrowKaz Stickman Studio. It covers intake, installing or checking
  the studio, creating the project, building word-level timestamps (Whisper or the user's timestamped script),
  and the story breakdown with the shot list.
metadata:
  version: "0.2.0"
  author: GrowKaz
---


## Start here: language, duration and optional references

Before choosing a niche, writing a script, installing dependencies, planning shots or rendering, ask one short intake message in the user's conversational language:
1. Which language should the video narration and on-screen text use? For example: Persian, English, or another language.
2. How long should the video be? For example: 60 seconds, 3-5 minutes, 8-10 minutes, or a custom duration.
3. If you have reference images or videos for the visual style, editing, animation or pacing, please attach them. References are optional; you can say you have none.

Wait for the user's answer. Do not silently select a language or duration. Reuse explicit choices already supplied for this video and ask only for missing information. Ask about references once; an answer that supplies language and duration without references is sufficient to continue, with no references assumed. Uploading or installing this file alone does not execute it: apply this intake when the user asks to use or start its workflow.

Use the selected language for narration, titles, hooks, captions and on-screen text. For Persian and Arabic use proper RTL layout, joined glyphs and suitable fonts. Inspect supplied references before planning; use their relevant style, pacing and composition as guidance, while creating original examples. If a reference cannot be accessed, say so and request an accessible attachment; never pretend to have watched it.

Record the choices in the project config as language (ISO code, e.g. fa or en), targetDurationSeconds (exact target or range), and referenceAssets (paths and intended use). Keep config.duration as the actual measured audio duration. Use the chosen language code with transcription --lang; never hard-code English. Preserve uploaded narration exactly. If the requested duration conflicts materially with the supplied narration, explain the measured length and ask whether to keep that length or receive revised narration; do not stretch, truncate, rewrite or pad it silently. If no narration is attached, request it after this intake before proceeding to the existing audio-based pipeline.


# /new-video: intake → install → timeline → story breakdown

This command covers stages 1–4 of the GrowKaz Stickman Studio pipeline. Shared references live in the sibling skill folder `../make-2d-video/references/` (relative to this skill's base directory), and the studio kit lives in `../make-2d-video/kit/`.

## 1. Intake
After completing the required start-here intake, ask once for missing production inputs, skipping anything already supplied:
- **Voiceover file** (required).
- **Script:** timestamped (SRT, VTT, JSON, or TXT with `[mm:ss]`), plain text, or none.
- **Aspect:** 16:9 or 9:16.
- **Resolution:** 720p / 1080p / 1440p / 2160p.
- **Captions:** default on for 9:16.
- **Music:** generated, own file, or none. **SFX:** on or off.
- **Title.**

Defaults: 16:9, 1080p, generated music + SFX.

## 2. Studio
If `growkaz-stickman-studio/render.mjs` doesn't exist in the workspace, follow `../make-2d-video/references/install.md` in full. Otherwise run `python tools/doctor.py` inside it and fix anything reported.

## 3. Project and timestamps (inside `growkaz-stickman-studio/`)
```bash
python tools/new_project.py --name <slug> --voice "<voiceover>" [--script "<script>"] --aspect <16:9|9:16> --resolution <res> --title "<title>" [--captions]
```
- **Timestamped script** → `python tools/parse_script.py --project projects/<slug> --script projects/<slug>/input/script.<ext>`. It accepts SRT, VTT, JSON (`[{start,end,text}]`, `{segments}`, `{words}`) and TXT lines like `[00:12.5] text`, `00:12 - 00:15 text` or `00:00:12,500 --> 00:00:15,000 text`. If the parser reports no timestamps, fall back to the plain-script route.
- **Plain script** → `python tools/transcribe.py --project projects/<slug> --script projects/<slug>/input/script.txt --lang <code> --model small`. It keeps the script's exact words with Whisper timing. Require ≥ 90% match; if lower, tell the user the script and audio differ.
- **No script** → `python tools/transcribe.py --project projects/<slug> --lang <code> --model small` (`base` for speed, `large-v3` for difficult audio). The first run downloads the model.

Open `timeline/transcript.txt` and confirm it reads correctly and ends near the voiceover length. Then run `python tools/beats.py --project projects/<slug>` (add `--force` to overwrite an existing shots.json).

## 4. Story breakdown
Read `../make-2d-video/references/style-bible.md` and `../make-2d-video/references/story-breakdown.md` fully, then:
1. Write `projects/<slug>/story/bible.md`: logline and tone, the cast (one saturated signature item each), locations (mood, key light, window view, props), motifs and the music plan.
2. Write `projects/<slug>/scenes/cast.js` with the outfits.
3. Rewrite `projects/<slug>/story/shots.json` following the pacing rules. Every shot needs a concrete `scene` description, plus transitions, bars, sfx and amb where they matter.
4. Send the user a 5–10 line summary: the cast, the locations, the shot count, and the highlights per act.

Finish by saying the next step is `/video-styles` (or continue with the full pipeline in the `make-2d-video` skill if the user asked for the whole video).
