import React from 'react';
import {Composition} from 'remotion';
import {TheLastShadow} from './the-last-shadow';

export const Root: React.FC = () => (
  <Composition
    id="TheLastShadow"
    component={TheLastShadow}
    durationInFrames={900}
    fps={30}
    width={1080}
    height={1920}
  />
);
