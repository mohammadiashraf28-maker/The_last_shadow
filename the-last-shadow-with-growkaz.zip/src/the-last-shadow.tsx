import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, useVideoConfig, interpolate, Easing, Audio} from 'remotion';
import {ThreeScene} from './three-scene';

const captions = [
  {from: 30, duration: 105, text: 'این خیابان هیچ‌وقت خالی نبود.'},
  {from: 165, duration: 105, text: 'یک نفر تعقیبش می‌کرد.'},
  {from: 330, duration: 105, text: 'پشت سرت را نگاه نکن.'},
  {from: 510, duration: 105, text: 'او همین حالا پشت سرت ایستاده.'},
  {from: 735, duration: 120, text: 'آخرین سایه'}
];

const Caption: React.FC<{text: string; start: number; duration: number}> = ({text, start, duration}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 12, duration - 12, duration], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{
      position: 'absolute', bottom: 245, width: '100%', textAlign: 'center',
      color: '#f2eeee', fontFamily: 'Arial, sans-serif', fontSize: 38,
      fontWeight: 700, letterSpacing: 1, textShadow: '0 3px 18px #000, 0 0 12px #9b111e',
      opacity, padding: '0 70px', boxSizing: 'border-box'
    }}>{text}</div>
  );
};

export const TheLastShadow: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fadeIn = interpolate(frame, [0, 45], [1, 0], {extrapolateRight: 'clamp'});
  const fadeOut = interpolate(frame, [855, 900], [0, 1], {extrapolateLeft: 'clamp'});
  return (
    <AbsoluteFill style={{backgroundColor: '#020207'}}>
      <ThreeScene />
      <AbsoluteFill style={{pointerEvents: 'none', background: 'radial-gradient(ellipse at center, transparent 35%, rgba(0,0,0,.78) 100%)'}} />
      {captions.map((c) => (
        <Sequence key={c.from} from={c.from} durationInFrames={c.duration}>
          <Caption text={c.text} start={c.from} duration={c.duration} />
        </Sequence>
      ))}
      <AbsoluteFill style={{backgroundColor: '#020207', opacity: Math.max(fadeIn, fadeOut), pointerEvents: 'none'}} />
      <Audio src={staticFile('horror-ambience.wav')} volume={0.8} />
    </AbsoluteFill>
  );
};
