import React, {useEffect, useRef} from 'react';
import * as THREE from 'three';
import {useCurrentFrame, useVideoConfig, interpolate, Easing} from 'remotion';

export const ThreeScene: React.FC = () => {
  const host = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<{
    renderer: THREE.WebGLRenderer; scene: THREE.Scene; camera: THREE.PerspectiveCamera;
    girl: THREE.Group; ghost: THREE.Group; lamps: THREE.PointLight[]; fog: THREE.Mesh;
    rain: THREE.Points; moon: THREE.Mesh;
  } | null>(null);
  const frame = useCurrentFrame();
  const {width, height, fps} = useVideoConfig();

  useEffect(() => {
    if (!host.current) return;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x03030a);
    scene.fog = new THREE.FogExp2(0x080812, 0.035);
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 3.3, 11);
    camera.lookAt(0, 1.7, -5);

    const renderer = new THREE.WebGLRenderer({antialias: true, alpha: false});
    renderer.setPixelRatio(1);
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    host.current.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0x303044, 1.3));
    const moonLight = new THREE.DirectionalLight(0x7185c7, 2.2);
    moonLight.position.set(-4, 8, 4); scene.add(moonLight);

    // Red moon
    const moon = new THREE.Mesh(new THREE.SphereGeometry(1.25, 32, 32), new THREE.MeshBasicMaterial({color: 0x8f1728}));
    moon.position.set(3.7, 6.6, -18); scene.add(moon);

    // Street and perspective alley
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(24, 60), new THREE.MeshStandardMaterial({color: 0x101019, roughness: 0.96}));
    ground.rotation.x = -Math.PI / 2; ground.position.set(0, -0.04, -13); scene.add(ground);
    const road = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 60), new THREE.MeshStandardMaterial({color: 0x171720, roughness: 0.9}));
    road.rotation.x = -Math.PI / 2; road.position.set(0, 0, -13); scene.add(road);

    // Buildings, windows and lamps
    const lamps: THREE.PointLight[] = [];
    for (let side of [-1, 1]) {
      for (let i = 0; i < 7; i++) {
        const z = -i * 5.4 - 1;
        const building = new THREE.Mesh(new THREE.BoxGeometry(3.4, 7 + (i%3), 4.8), new THREE.MeshStandardMaterial({color: side < 0 ? 0x171722 : 0x11111b, roughness: 1}));
        building.position.set(side * 4.1, 3.2, z); scene.add(building);
        for (let w = 0; w < 3; w++) {
          const window = new THREE.Mesh(new THREE.PlaneGeometry(0.48, 0.8), new THREE.MeshBasicMaterial({color: (i+w)%4===0 ? 0x8c2634 : 0x252638}));
          window.position.set(side*4.1 - side*1.72, 3.1 + (w%2)*1.4, z + (w-1)*1.1 + 2.43);
          window.rotation.y = side < 0 ? 0 : Math.PI; scene.add(window);
        }
        if (i < 5) {
          const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.045,0.07,3.2,8), new THREE.MeshStandardMaterial({color:0x25252d, metalness:.5}));
          pole.position.set(side*2.4,1.6,z); scene.add(pole);
          const bulb = new THREE.Mesh(new THREE.SphereGeometry(.16,12,12), new THREE.MeshBasicMaterial({color:0xd7b4a1}));
          bulb.position.set(side*2.4,3.25,z); scene.add(bulb);
          const light = new THREE.PointLight(0xffb18a, 12, 8, 2);
          light.position.set(side*2.4,3.1,z); scene.add(light); lamps.push(light);
        }
      }
    }

    // Girl silhouette: stylized anime-inspired geometry, no external model needed
    const girl = new THREE.Group(); scene.add(girl); girl.position.set(0,0,2.0);
    const coatMat = new THREE.MeshStandardMaterial({color:0x090a12, roughness:.85});
    const skinMat = new THREE.MeshStandardMaterial({color:0xb9a1a0, roughness:.8});
    const hairMat = new THREE.MeshStandardMaterial({color:0x05050a, roughness:.5});
    const torso = new THREE.Mesh(new THREE.ConeGeometry(.55,1.7,7), coatMat); torso.position.y=1.55; girl.add(torso);
    const head = new THREE.Mesh(new THREE.SphereGeometry(.39,24,20), skinMat); head.position.y=2.62; head.scale.set(.82,1.08,.82); girl.add(head);
    const hair = new THREE.Mesh(new THREE.SphereGeometry(.48,20,16), hairMat); hair.position.set(0,2.83,-.05); hair.scale.set(1.12,1.05,1.0); girl.add(hair);
    for(let i=0;i<7;i++){
      const strand = new THREE.Mesh(new THREE.ConeGeometry(.12,.95,7),hairMat);
      strand.position.set((i-3)*.12,2.25,-.13); strand.rotation.z=(i-3)*-.13; girl.add(strand);
    }
    for (let s of [-1,1]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(.13,.18,1.05,8),coatMat); leg.position.set(s*.2,.53,0); girl.add(leg);
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(.09,.12,1.0,8),coatMat); arm.position.set(s*.58,1.6,0); arm.rotation.z=s*.18; girl.add(arm);
    }

    // Shadow creature, initially far behind her
    const ghost = new THREE.Group(); scene.add(ghost); ghost.position.set(0,0,-11);
    const ghostMat = new THREE.MeshStandardMaterial({color:0x030207, roughness:.3, metalness:.15});
    const body = new THREE.Mesh(new THREE.ConeGeometry(.85,3.5,8),ghostMat); body.position.y=1.8; ghost.add(body);
    const gHead = new THREE.Mesh(new THREE.SphereGeometry(.56,20,16),ghostMat); gHead.position.y=3.65; gHead.scale.set(.75,1.25,.7); ghost.add(gHead);
    for (let s of [-1,1]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(.085,12,12),new THREE.MeshBasicMaterial({color:0xff1738}));
      eye.position.set(s*.19,3.72,.47); ghost.add(eye);
    }
    for(let i=0;i<5;i++){
      const tendril = new THREE.Mesh(new THREE.ConeGeometry(.13,2.3,6),ghostMat);
      tendril.position.set((i-2)*.28,1.3,-.15); tendril.rotation.z=(i-2)*.22; ghost.add(tendril);
    }

    // Atmospheric fog sheets
    const fogMat = new THREE.MeshBasicMaterial({color:0x55566f,transparent:true,opacity:.10,depthWrite:false});
    const fog = new THREE.Mesh(new THREE.PlaneGeometry(18,3),fogMat);
    fog.position.set(0,.65,-3); scene.add(fog);

    // Rain particles
    const count=900, positions=new Float32Array(count*3);
    for(let i=0;i<count;i++){ positions[i*3]=(Math.random()-.5)*16; positions[i*3+1]=Math.random()*12; positions[i*3+2]=-Math.random()*28; }
    const rainGeo=new THREE.BufferGeometry(); rainGeo.setAttribute('position',new THREE.BufferAttribute(positions,3));
    const rain=new THREE.Points(rainGeo,new THREE.PointsMaterial({color:0x9aa6c8,size:.025,transparent:true,opacity:.42}));
    scene.add(rain);

    sceneRef.current={renderer,scene,camera,girl,ghost,lamps,fog,rain,moon};
    return ()=>{ renderer.dispose(); if(host.current && renderer.domElement.parentNode===host.current) host.current.removeChild(renderer.domElement); };
  }, [width,height]);

  useEffect(() => {
    const s=sceneRef.current; if(!s) return;
    const t=frame/30;
    const reveal=interpolate(frame,[390,570],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.inOut(Easing.cubic)});
    const cameraShake=frame>500 ? Math.sin(frame*.9)*.035*reveal : Math.sin(frame*.08)*.012;
    s.camera.position.set(cameraShake,3.3+Math.sin(t*1.2)*.035,11);
    s.camera.lookAt(0,1.7,-5);
    s.girl.position.z=2-Math.min(frame/450,1)*1.3;
    s.girl.position.x=Math.sin(t*1.4)*.08;
    s.girl.rotation.y=frame>320 ? interpolate(frame,[320,430],[0,Math.PI*.75],{extrapolateRight:'clamp'}) : Math.sin(t)*.025;
    s.ghost.position.z=-11+reveal*8.2;
    s.ghost.scale.setScalar(.75+reveal*.38);
    s.ghost.rotation.y=Math.sin(t*.7)*.08;
    s.ghost.visible=frame>360;
    s.lamps.forEach((l,i)=>{ const flicker=Math.max(.08,1-(frame/900)*.5)*(0.55+0.45*Math.sin(frame*.21+i*9)); l.intensity=12*flicker*(frame>690?.15:1); });
    const attr=s.rain.geometry.getAttribute('position') as THREE.BufferAttribute;
    const arr=attr.array as Float32Array;
    for(let i=0;i<arr.length;i+=3){arr[i+1]-=.16;if(arr[i+1]<0)arr[i+1]=12;}
    attr.needsUpdate=true;
    s.fog.position.x=Math.sin(t*.3)*1.5;
    s.fog.material && ((s.fog.material as THREE.MeshBasicMaterial).opacity=.06+Math.sin(t*.5)*.025);
    s.renderer.render(s.scene,s.camera);
  }, [frame]);

  return <div ref={host} style={{position:'absolute',inset:0,width:'100%',height:'100%'}} />;
};
