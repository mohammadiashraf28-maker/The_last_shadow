# Optional GrowKaz Studio integration

This project now includes the GrowKaz Stickman Studio toolkit under `growkaz-stickman-studio/`.
It is a companion renderer, not a replacement for the original Remotion composition.

## Which renderer should I use?

- **Original anime-horror 3D short:** use the root project (`npm run dev`, `npm run render`).
  It uses Three.js directly inside Remotion, with a 1080x1920, 30 fps, 30-second composition.
- **GrowKaz companion pipeline:** use `growkaz-stickman-studio/` for its code-drawn 2D/2.5D scenes,
  low-poly Three.js shots, shot planning, sound generation, contact sheets, and frame-by-frame MP4 rendering.
  Its visual identity is cinematic stick-figure animation, so it does not automatically convert the anime
  characters in the root project into detailed anime models.

## Companion toolkit setup

Requirements from the supplied plugin guide:
- Node.js 18 or newer
- Python 3.9 or newer
- ffmpeg + ffprobe
- npm dependencies and Playwright Chromium
- Python packages: numpy, scipy, faster-whisper

From this directory:

```bash
cd growkaz-stickman-studio
npm install
npx playwright install chromium
python -m pip install numpy scipy faster-whisper
python tools/verify_kit.py
python tools/doctor.py
```

On Linux, if Chromium system libraries are missing, use:
```bash
npx playwright install-deps chromium
```

Run the bundled example contact-sheet self-test:
```bash
node render.mjs --project examples/reaction-time --sheet --scale 0.3
```

## Installation status in the build environment

- The plugin source kit is copied into this project and its integrity check passed (29/29 files).
- Node.js 22, Python 3.13, ffmpeg/ffprobe, numpy and scipy are present in the build environment.
- npm packages, Playwright Chromium and faster-whisper are not installed yet. The npm registry lookup timed out with a DNS/network error (`EAI_AGAIN`), so the toolkit has not been falsely marked as runnable here.
- On a machine with internet access, run the setup commands above. The first Whisper transcription also downloads a speech model.

## Important integration boundary

The plugin's rendering engine is independent of Remotion. It can produce a silent MP4 and then mix its own
music/SFX using `python audio/mix.py --project projects/<slug>`. Remotion remains the main pipeline for
this specific Three.js anime-horror project, including its subtitles, audio track and final MP4 render.
The two engines are kept side-by-side to avoid overwriting the working project or changing its art direction.

See `PLUGIN_GUIDE.md` and `docs/` for the full supplied instructions.
